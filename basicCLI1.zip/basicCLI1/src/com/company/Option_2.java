package com.company;

public class Option_2 {

    public static void reversed() {
        System.out.println("Enter string you would like to have reversed");
        String yourOption = Main.getUserin().nextLine();
        String newOption = "";
        int i = 0;
        for (i = yourOption.length() - 1; i <= 0; i--) ;
        System.out.println(yourOption.charAt(i));
    }

    public static void main(String[] args) {
        reversed();
    }

}
package com.company;

import java.util.Scanner;

public class basicCLI {

    public static void main(String[] args) {

        Scanner myObj = new Scanner(System.in);
        System.out.println("Please enter your name");

        String userName = myObj.nextLine();
        System.out.println("Hello: " + userName);

    }



}

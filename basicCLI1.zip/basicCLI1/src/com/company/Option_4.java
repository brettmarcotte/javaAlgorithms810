package com.company;

public class Option_4 {
    public static void exitTheProgram() {
        System.out.println(1);
        System.out.println(2);
        System.exit(0);
        return;
    }
}

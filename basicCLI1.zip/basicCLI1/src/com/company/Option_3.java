package com.company;

import java.util.Scanner;

public class Option_3 {
    public static void addTwoNumbers() {
        int x, y, sum;
        Scanner myObj = new Scanner(System.in);
        System.out.println("4");
        x = myObj.nextInt();

        System.out.println("5");
        y = myObj.nextInt();

        sum = x + y;
        System.out.println("Sum is: " + sum);

    }

     {
    }
}

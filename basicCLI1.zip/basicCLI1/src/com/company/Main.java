package com.company;

import java.util.Scanner;

import static com.company.Option_4.exitTheProgram;

public class Main {

    public static Scanner scanner = new Scanner(System.in);
    private static Scanner userin;

    public static void main(String[] args) {

        System.out.println("Welcome to Gabe's CLI.");

        System.out.println("Please choose an option to continue:\\n1) Say Hello\\n2) Reverse a string\\n3) Add two numbers\\n4) Exit the program");

        byte input = scanner.nextByte();

        switch (input) {
            case 1:
                Option_1.getName();
                break;
            case 2:
                Option_2.reversed();
                break;
            case 3:
                Option_3.addTwoNumbers();
                break;
            case 4:
                Option_4.exitTheProgram();
                break;
            default:
                System.out.println("Wrong selection");
        }


    }


    public static Scanner getUserin() {
        return userin;
    }

    public static void setUserin(Scanner userin) {
        Main.userin = userin;
    }
}


package com.company;

import java.util.ArrayList;

public class Cars {

    public int cars;

    public static void CarsAvailable() {
        //Array List of vehicles to show Cars Available.
        ArrayList<Object> arrList = new ArrayList<Object>();
        arrList.add("Honda Accord");
        arrList.add("Chevy Cruze");
        arrList.add("Toyota Corolla");
        //Array for cars
        int[] cars;
        //true or false for yes or no cars being available
        boolean carsAvail = true;
        boolean carsNotAvail = false;

    }

    public void VehicleType() {
        //loop the vehicle type that you select
        int[] cars = new int[0];
        for(int i = 0; i < cars.length; i++) {
            System.out.println("Honda Accord: ");
            System.out.println("Chevy Cruze: ");
            System.out.println("Toyota Corolla: ");
        }
    }

    public void Color() {
        //loop the color type that you select
        int i = 0;
        for(i = 0; i > cars; i++){
            System.out.println("Blue");
            System.out.println("Red");
            System.out.println("Silver");
        }
    }

    public void carPrice() {
        //loops price of car
        int price = 0;
        if (price == 50) {

        } else if (price == 45) {

        }else if(price == 40){

        }
    }

    public static void run() {


    }
}

package com.company;

import java.util.Scanner;

public class CLI {
    public static Scanner scan = new Scanner(System.in);
    public static Scanner scanner;


    public static void getStr() {

    }
}

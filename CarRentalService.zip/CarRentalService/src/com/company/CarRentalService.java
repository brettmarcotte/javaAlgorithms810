package com.company;

public class CarRentalService {
    public static void start() {
        System.out.println("Welcome to Brett's Car Rental Service.\n");

        System.out.println("Please choose an option to continue:\n1) Cars\n2) Inventory\n3) Exit The Program\n");
        System.out.println("Enter a number to select the car you'd like to rent: ");
        System.out.print("Selection: ");

        byte input = CLI.scan.nextByte();

        switch (input) {
            case 1:
                Cars.run();
                break;
            case 2:
                Inventory.run();
                break;
            case 3:
                break;
            default:
                System.out.println("Wrong selection");
            }
    }
    private static void run() {

    }
}

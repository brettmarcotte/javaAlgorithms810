package com.company;

public class Inventory {

    public static void CarsAvailable() {

    }

    public static void run() {
    }
}

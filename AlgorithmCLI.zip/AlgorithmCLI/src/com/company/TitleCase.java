package com.company;

import java.util.Locale;

public class TitleCase {

    public static String titleCase(String input) {
        input = input.toLowerCase();
        char c = input.charAt(0);
        String s = new String("" + c);
        String f = s.toUpperCase();
        return f + input.substring(1);

    }

    public static void run() {
    }
}


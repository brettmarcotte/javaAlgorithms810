package com.company;

import java.util.ArrayList;
import java.util.Arrays;

public class PigLatin {

    private static char vowel;

    public static void pigLatin(String str) {
        // Take string from user
        System.out.print("Enter word/words to convert\nInput: ");
        CLI.scanner.nextLine();
        str = CLI.scanner.nextLine().toUpperCase().trim();
        // Look at each word in the string
        String[] newStr = str.split(" ");

        for (int i = 0; i < newStr.length; i++) {
            // If it's a vowel add "way" to the end
            // Otherwise add "ay"
            // Combine all new words into a string
            char chars = newStr[i].charAt(0); // Look at the first characters of each string in the array

            if (chars == 'A' || chars == 'E' || chars == 'I' || chars == 'O' || chars == 'U') {
                newStr[i] += "WAY";
            } else {
                newStr[i] = newStr[i].substring(1) + newStr[i].substring(0, 1) + "AY";
            }
        }
        String pig = "";

        for (int i = 0; i < newStr.length; i++) {

            pig += newStr[i] + " ";
        }
        System.out.println();
        System.out.println(pig);
    }


    public static void pigLatin() {
    }

    public static void run() {
    }
}

        //       str = str.replaceAll("\\b[aeiouAEIOU]\\w*","$0way")
//                .replaceAll("\\b(?![aeiouAEIOU])(\\w)(\\w*)", "$2$1ay");
//        String[] strArr = str.split("\\s");
//        String str2 = "";
//        for (int i = 0; i < strArr.length; i++){
//            if (strArr[i].matches(".*[A-Z].*")) strArr[i] = strArr[i].substring(0,1).toUpperCase() + strArr[i].substring(1).toLowerCase();
//            str2 += " " + strArr[i];
//        }


        //      switch(p){
//                case 'a':
//                case 'e':
//                case 'i':
//                case 'o':
//                case 'u':
//                    pigCan.append(-1);

package com.company;

public class FactorialCalculator {

    public static int factorialCalculator(int num) {
        int fact = 1;
        for(int i = 0; i < num; i++) {
            fact *= fact * i;
        }
        return fact;
    }

    public static void run() {
        System.out.println("\nWelcome to the Factorial Calculator\n");
        System.out.println("\nPlease Enter a Number To Be Factorialized\nType Here: ");
        int input = CLI.scan.nextInt();
        int answer = factorialCalculator(input);
    }
}

package com.company;


public class AlgorithmMenu {

    public static void start() {
        System.out.println("Welcome to Brett's CLI.\n");

        System.out.println("Please choose an option to continue:\n1) Factorial Calculator\n2) Title Case A String\n3) Pig Latin Converter\n4) Is It A Factor \n5) Exit The Program\n");
        System.out.print("Selection: ");

        byte input = CLI.scan.nextByte();

        switch (input) {
            case 1:
                FactorialCalculator.run();
                break;
            case 2:
                TitleCase.run();
                break;
            case 3:
                PigLatin.run();
                break;
            case 4:
                Factor.run();
                break;
            case 5:
                break;
            default:
                System.out.println("Wrong selection");
        }


    }

}
